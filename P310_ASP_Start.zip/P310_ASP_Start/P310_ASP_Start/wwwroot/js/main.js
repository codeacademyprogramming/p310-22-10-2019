﻿
$(document).on("click", ".arrivals ul > li.toggle__pros", function () {
    var catId = $(this).attr("id");

    $(".accordionProducts .all").hide().filter("." + catId).show();
    $(".arrivals ul > li.toggle__pros").removeClass("active");
    $(this).addClass("active");
});